#!/bin/bash
HOST=$1

echo "[INFO] Coletando informações do host $HOST..."
ssh "$HOST" '
  echo "Hostname: $(hostname)"
  echo "Distro: $(cat /etc/os-release | grep PRETTY_NAME | cut -d= -f2 | tr -d "\"")"
  echo "Kernel: $(uname -r)"
  echo "CPU: $(lscpu | grep "Model name" | cut -d: -f2 | xargs)"
  echo "Memória Total: $(free -h | grep Mem | awk "{print \$2}")"
  echo "Uptime: $(uptime -p)"
'
