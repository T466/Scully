#!/bin/bash

HOST=$1
TARGET_FILE=$2
OLD_VALUE=$3
NEW_VALUE=$4

if [ $# -ne 4 ]; then
    echo "Uso: replace <host> <arquivo> <valor_antigo> <valor_novo>"
    exit 1
fi

ssh "$HOST" "sudo sed -i 's|$OLD_VALUE|$NEW_VALUE|g' $TARGET_FILE" \
  && echo "[OK] Substituído '$OLD_VALUE' por '$NEW_VALUE' em $HOST:$TARGET_FILE" \
  || echo "[ERRO] Falha ao modificar $TARGET_FILE em $HOST"
