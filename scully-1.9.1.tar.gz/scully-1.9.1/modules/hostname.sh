#!/bin/bash

NOVO_HOSTNAME=$1

if [[ -z "$NOVO_HOSTNAME" ]]; then
  echo "ERRO: Uso: hostname.sh <novo_hostname>"
  exit 1
fi

# Aplica hostname temporariamente
hostnamectl set-hostname "$NOVO_HOSTNAME"

# Confirmação
if [[ $? -eq 0 ]]; then
  echo "✅ Hostname definido como: $NOVO_HOSTNAME"
else
  echo "❌ Falha ao definir o hostname"
  exit 1
fi
