#!/bin/bash

echo "Instalando Scully em /opt/scully ..."

# Define hostname teste do inventory
HOSTNAME=$(hostname)

# Define destino
INSTALL_DIR="/opt/scully"

# Cria estrutura
sudo mkdir -p "$INSTALL_DIR/inventories/"

# Move os arquivos diretamente para o destino
sudo cp -f scully.sh  "$INSTALL_DIR/"
sudo cp -r modules "$INSTALL_DIR"

# Garante permissões
sudo chmod +x "$INSTALL_DIR/scully.sh"
sudo chmod +x "$INSTALL_DIR/modules/"*.sh
sudo chown -R scully:scully "$INSTALL_DIR"

# Adicionar ao PATH


if [ -L /usr/local/bin/scully ]; then
  rm /usr/local/bin/scully
else
  echo " "
fi

ln -s /opt/scully/scully.sh /usr/local/bin/scully
chmod +x /opt/scully/scully.sh

# Envia hostname teste do inventory
echo $HOSTNAME > /opt/scully/inventories/inventory

echo "Scully instalado com sucesso em $INSTALL_DIR"
echo "Execute com: scully -i /opt/scully/inventories/inventory all -m ping"
