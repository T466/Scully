#!/bin/bash

# Resolve o caminho real do script, mesmo via symlink
SOURCE="${BASH_SOURCE[0]}"
while [ -h "$SOURCE" ]; do
  DIR="$(cd -P "$(dirname "$SOURCE")" >/dev/null 2>&1 && pwd)"
  SOURCE="$(readlink "$SOURCE")"
  [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE"
done
SCULLY_DIR="$(cd -P "$(dirname "$SOURCE")" >/dev/null 2>&1 && pwd)"
MODULE_DIR="$SCULLY_DIR/modules"

# INVENTORY padrão (pode ser sobrescrito por -i)
INVENTORY="$SCULLY_DIR/inventory"

# Detecta uso da flag -i
if [ "$1" == "-i" ]; then
    INVENTORY="$2"
    shift 2
fi

# Função de ajuda integrada
usage() {
    echo "==============================================="
    echo "             AJUDA - Scully CLI                "
    echo "==============================================="
    echo
    echo "USO:"
    echo "  scully <alvo> -m <modulo> [argumentos...]"
    echo
    echo "Exemplo:"
    echo "  scully -i /opt/scully/inventories/inventory all -m ping"
    echo
    echo "MÓDULOS DISPONÍVEIS:"
    echo
    echo "🔹 ping        -> Testa conectividade via ping"
    echo "     Uso: scully -i /opt/scully/inventories/inventory all -m ping"
    echo
    echo "🔹 copy        -> Copia um arquivo para o host remoto"
    echo "     Uso: scully -i /opt/scully/inventories/inventory all -m copy /origem/arquivo.txt /destino/arquivo.txt"
    echo
    echo "🔹 user        -> Cria um novo usuário no host remoto"
    echo "     Uso: scully -i /opt/scully/inventories/inventory all -m user nome_usuario"
    echo
    echo "🔹 replace     -> Substitui uma sentença por outra num arquivo remoto"
    echo "     Uso: scully -i /opt/scully/inventories/inventory all -m replace /caminho/arquivo 'antigo' 'novo'"
    echo
    echo "🔹 service     -> Gerencia serviços com systemctl"
    echo "     Uso: scully -i /opt/scully/inventories/inventory all -m service <serviço> <ação>"
    echo "     Ações suportadas: start | stop | restart | enable | disable | status"
    echo
    echo "🔹 package     -> Gerencia pacotes via apt ou yum"
    echo "     Uso: scully -i /opt/scully/inventories/inventory all -m package <nome_do_pacote> <ação>"
    echo "     Ações suportadas: install | remove"
    echo
    echo "🔹 cron        -> Adiciona ou remove tarefas agendadas (crontab)"
    echo "     Uso: scully -i /opt/scully/inventories/inventory all -m cron add \"* * * * * echo hello\""
    echo "     Uso: scully -i /opt/scully/inventories/inventory all -m cron remove \"* * * * * echo hello\""
    echo
    echo "🔹 reboot      -> Reinicia o host remoto"
    echo "     Uso: scully -i /opt/scully/inventories/inventory all -m reboot"
    echo
    echo "🔹 facts       -> Coleta informações do sistema remoto"
    echo "     Uso: scully -i /opt/scully/inventories/inventory all -m facts"
    echo
    echo "🔹 file        -> Cria arquivos ou diretórios com permissões específicas"
    echo "     Uso: scully -i /opt/scully/inventories/inventory all -m file /tmp/test.txt touch 644"
    echo "     Uso: scully -i /opt/scully/inventories/inventory grupo1 -m file /opt/scripts directory 755"
    echo
    echo "🔹 firewall    -> Ativa ou remove regras de firewall com firewalld ou iptables"
    echo "     Uso: scully -i /opt/scully/inventories/inventory all -m firewall open 22/tcp"
    echo "     Uso: scully -i /opt/scully/inventories/inventory all -m firewall close 8080/tcp"
    echo
    echo "🔹 group       -> Cria ou remove grupos no sistema"
    echo "     Uso: scully -i /opt/scully/inventories/inventory all -m group add devops"
    echo "     Uso: scully -i /opt/scully/inventories/inventory all -m group remove analistas"
    echo
    echo "🔹 hostname    -> Define o nome do host remoto"
    echo "     Uso: scully -i /opt/scully/inventories/inventory 10.10.10.2 -m hostname webserver01"
    echo "     Uso: scully -i /opt/scully/inventories/inventory grupo1 -m hostname db-node-02"
    echo
    echo "  ARQUIVO DE INVENTÁRIO:"
    echo "  Editar: $SCULLY_DIR/inventory"
    echo "  Formato: um IP ou hostname por linha"
    echo
    echo "🔹 shell       -> Executa comandos com recursos de shell (|, &&, >, etc)"
    echo "     Uso: scully -i /opt/scully/inventories/inventory all -m shell \"df -h | grep /dev\""
    echo "     Uso: scully -i /opt/scully/inventories/inventory grupo1 -m shell \"systemctl restart nginx && echo OK\""
    echo
    echo "USO:"
    echo "  scully [-i caminho_inventory] <alvo> -m <modulo> [argumentos...]"
    echo
    echo "Exemplos:"
    echo "  scully all -m ping"
    echo "  scully -i /opt/scully/inventories/inventory all -m shell \"uptime\""
    echo
    echo "🔹 ping        -> Testa conectividade via ping"
    echo "     Uso: scully -i /opt/scully/inventories/inventory all -m ping"
    echo
    echo "🔹 shell       -> Executa comandos com recursos de shell (|, &&, >, etc)"
    echo "     Uso: scully -i /opt/scully/inventories/inventory grupo1 -m shell \"systemctl restart nginx && echo OK\""
    echo
    echo "ARQUIVO DE INVENTÁRIO:"
    echo "  Atual: $INVENTORY"
    echo "  Formato:"
    echo "     [grupo1]"
    echo "     192.168.15.51"
    echo "     scully"
    echo
    echo "DICA:"
    echo "  Configure chaves SSH para acesso sem senha"
    echo
    echo "==============================================="
    echo " Desenvolvido por Thiago Freitas - T466"
    echo "==============================================="
    exit 1
}

SCULLY_VERSION="1.9.3"

# Exibe ajuda se -h ou --help for chamado
[ "$1" == "-h" ] || [ "$1" == "--help" ] && usage


# Exibe versão
[ "$1" == "-v" ] || [ "$1" == "--version" ] && {
    echo "Scully CLI - Versão $SCULLY_VERSION"
    exit 0
}

# Validação dos parâmetros
[ "$#" -lt 3 ] || [ "$2" != "-m" ] && usage

ALVO="$1"
MODULO="$3"
MODULO_PATH="$MODULE_DIR/$MODULO.sh"

if [ ! -f "$MODULO_PATH" ]; then
    echo "[ERRO] Módulo '$MODULO' não encontrado em $MODULE_DIR"
    exit 2
fi

# Resolve hosts do inventory
if [ "$ALVO" == "all" ]; then
    HOSTS=$(grep -vE '^#|^\[.*\]|^$' "$INVENTORY")
elif grep -q "^\[$ALVO\]" "$INVENTORY"; then
    HOSTS=$(awk "/^\[$ALVO\]/ {flag=1; next} /^\[.*\]/ {flag=0} flag" "$INVENTORY")
else
    HOSTS="$ALVO"
fi

# Executa o módulo para cada host
for HOST in $HOSTS; do
    echo "🔧 [$HOST] Executando $MODULO..."
    bash "$MODULO_PATH" "$HOST" "${@:4}"
done
