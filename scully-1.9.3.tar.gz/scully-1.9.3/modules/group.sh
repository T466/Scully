#!/bin/bash

HOST=$1
ACAO=$2
GRUPO=$3

if [[ -z "$ACAO" || -z "$GRUPO" ]]; then
  echo "ERRO: Uso: group.sh <host> <add|remove> <nome_do_grupo>"
  exit 1
fi

if [[ "$ACAO" == "add" ]]; then
  ssh "$HOST" "getent group '$GRUPO' > /dev/null && echo 'Grupo $GRUPO já existe' || (groupadd '$GRUPO' && echo 'Grupo $GRUPO criado com sucesso')"
elif [[ "$ACAO" == "remove" ]]; then
  ssh "$HOST" "getent group '$GRUPO' > /dev/null && (groupdel '$GRUPO' && echo 'Grupo $GRUPO removido com sucesso') || echo 'Grupo $GRUPO não existe'"
else
  echo "Ação inválida. Use 'add' ou 'remove'"
  exit 1
fi

