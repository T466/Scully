#!/bin/bash

HOST=$1
PATH_TARGET=$2
STATE=$3
MODE=$4

if [[ -z "$PATH_TARGET" || -z "$STATE" || -z "$MODE" ]]; then
  echo "ERRO: Uso: file.sh <host> <path> <touch|directory> <mode>"
  exit 1
fi

case "$STATE" in
  touch)
    ssh "$HOST" "touch '$PATH_TARGET' && chmod $MODE '$PATH_TARGET' && echo 'Arquivo $PATH_TARGET criado com permissão $MODE'"
    ;;
  directory)
    ssh "$HOST" "mkdir -p '$PATH_TARGET' && chmod $MODE '$PATH_TARGET' && echo 'Diretório $PATH_TARGET criado com permissão $MODE'"
    ;;
  *)
    echo "ERRO: Estado inválido. Use 'touch' ou 'directory'."
    exit 1
    ;;
esac
