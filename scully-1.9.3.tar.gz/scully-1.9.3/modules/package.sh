#!/bin/bash
HOST=$1
PACKAGE=$2
ACTION=$3

if [ -z "$HOST" ] || [ -z "$PACKAGE" ] || [ -z "$ACTION" ]; then
    echo "[ERRO] Uso: scully all -m package <pacote> <install|remove>"
    exit 1
fi

# Gera o comando de instalação baseado no sistema remoto
ssh "$HOST" "bash -s" <<EOF
if command -v yum &> /dev/null; then
    if [ "$ACTION" == "install" ]; then
        sudo yum install -y $PACKAGE
    elif [ "$ACTION" == "remove" ]; then
        sudo yum remove -y $PACKAGE
    else
        echo '[ERRO] Ação inválida. Use install ou remove.'
        exit 1
    fi
elif command -v apt &> /dev/null; then
    sudo apt update -y
    if [ "$ACTION" == "install" ]; then
        sudo apt install -y $PACKAGE
    elif [ "$ACTION" == "remove" ]; then
        sudo apt remove -y $PACKAGE
    else
        echo '[ERRO] Ação inválida. Use install ou remove.'
        exit 1
    fi
else
    echo '[ERRO] Gerenciador de pacotes não suportado.'
    exit 1
fi
EOF
