#!/bin/bash

HOST=$1
ACAO=$2
PORTA_PROTOCOLO=$3

if [[ -z "$ACAO" || -z "$PORTA_PROTOCOLO" ]]; then
  echo "ERRO: Uso: firewall.sh <host> <open|close> <porta>/<protocolo>"
  exit 1
fi

COMANDO_FIREWALL=""

if ssh "$HOST" "command -v firewall-cmd &>/dev/null"; then
  if [[ "$ACAO" == "open" ]]; then
    COMANDO_FIREWALL="firewall-cmd --permanent --add-port=$PORTA_PROTOCOLO && firewall-cmd --reload && echo 'Porta $PORTA_PROTOCOLO aberta com firewalld'"
  elif [[ "$ACAO" == "close" ]]; then
    COMANDO_FIREWALL="firewall-cmd --permanent --remove-port=$PORTA_PROTOCOLO && firewall-cmd --reload && echo 'Porta $PORTA_PROTOCOLO fechada com firewalld'"
  else
    echo "Ação inválida. Use open ou close"
    exit 1
  fi
elif ssh "$HOST" "command -v iptables &>/dev/null"; then
  if [[ "$ACAO" == "open" ]]; then
    COMANDO_FIREWALL="iptables -A INPUT -p ${PORTA_PROTOCOLO##*/} --dport ${PORTA_PROTOCOLO%%/*} -j ACCEPT && echo 'Porta $PORTA_PROTOCOLO aberta com iptables'"
  elif [[ "$ACAO" == "close" ]]; then
    COMANDO_FIREWALL="iptables -D INPUT -p ${PORTA_PROTOCOLO##*/} --dport ${PORTA_PROTOCOLO%%/*} -j ACCEPT && echo 'Porta $PORTA_PROTOCOLO fechada com iptables'"
  else
    echo "Ação inválida. Use open ou close"
    exit 1
  fi
else
  echo "Nenhum gerenciador de firewall encontrado (firewalld ou iptables)"
  exit 1
fi

# Executa remotamente
ssh "$HOST" "$COMANDO_FIREWALL"
