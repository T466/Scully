#!/bin/bash

ACAO=$1
PORTA_PROTOCOLO=$2

if [[ -z "$ACAO" || -z "$PORTA_PROTOCOLO" ]]; then
  echo "ERRO: Uso: firewall.sh <open|close> <porta>/<protocolo>"
  exit 1
fi

if command -v firewall-cmd &> /dev/null; then
  # Com firewalld
  if [[ "$ACAO" == "open" ]]; then
    firewall-cmd --permanent --add-port="$PORTA_PROTOCOLO"
    firewall-cmd --reload
    echo "Porta $PORTA_PROTOCOLO aberta com firewalld"
  elif [[ "$ACAO" == "close" ]]; then
    firewall-cmd --permanent --remove-port="$PORTA_PROTOCOLO"
    firewall-cmd --reload
    echo "Porta $PORTA_PROTOCOLO fechada com firewalld"
  else
    echo "Ação inválida. Use open ou close"
    exit 1
  fi

elif command -v iptables &> /dev/null; then
  # Com iptables (modo simplificado)
  if [[ "$ACAO" == "open" ]]; then
    iptables -A INPUT -p ${PORTA_PROTOCOLO##*/} --dport ${PORTA_PROTOCOLO%%/*} -j ACCEPT
    echo "Porta $PORTA_PROTOCOLO aberta com iptables"
  elif [[ "$ACAO" == "close" ]]; then
    iptables -D INPUT -p ${PORTA_PROTOCOLO##*/} --dport ${PORTA_PROTOCOLO%%/*} -j ACCEPT
    echo "Porta $PORTA_PROTOCOLO fechada com iptables"
  else
    echo "Ação inválida. Use open ou close"
    exit 1
  fi

else
  echo "Nenhum gerenciador de firewall encontrado (firewalld ou iptables)"
  exit 1
fi
