#!/bin/bash

HOST=$1
NOVO_HOSTNAME=$2

if [[ -z "$NOVO_HOSTNAME" ]]; then
  echo "ERRO: Uso: hostname.sh <host> <novo_hostname>"
  exit 1
fi

ssh "$HOST" "hostnamectl set-hostname '$NOVO_HOSTNAME'"

# Confirmação remota
if [[ $? -eq 0 ]]; then
  echo "✅ Hostname definido como: $NOVO_HOSTNAME"
else
  echo "❌ Falha ao definir o hostname em $HOST"
  exit 1
fi

