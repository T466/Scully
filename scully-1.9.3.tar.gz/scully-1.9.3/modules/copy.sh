#!/bin/bash
HOST=$1
SRC=$2
DEST=$3
scp "$SRC" "$HOST:$DEST"
