#!/bin/bash
HOST=$1
ACTION=$2
CRON_ENTRY=$3

if [ -z "$HOST" ] || [ -z "$ACTION" ] || [ -z "$CRON_ENTRY" ]; then
    echo "[ERRO] Uso: scully all -m cron <add|remove> '<linha_cron>'"
    exit 1
fi

# Adiciona ou remove a entrada no crontab do usuário atual no host remoto
ssh "$HOST" "bash -s" <<EOF
TMP_CRON=\$(mktemp)
crontab -l 2>/dev/null > \$TMP_CRON

if [ "$ACTION" == "add" ]; then
    grep -Fxq "$CRON_ENTRY" \$TMP_CRON || echo "$CRON_ENTRY" >> \$TMP_CRON
    crontab \$TMP_CRON
    echo "[OK] Entrada adicionada no crontab de $HOST"
elif [ "$ACTION" == "remove" ]; then
    grep -Fxv "$CRON_ENTRY" \$TMP_CRON > \${TMP_CRON}.new
    crontab \${TMP_CRON}.new
    echo "[OK] Entrada removida do crontab de $HOST"
else
    echo "[ERRO] Ação inválida. Use add ou remove."
    exit 1
fi

rm -f \$TMP_CRON \${TMP_CRON}.new
EOF
