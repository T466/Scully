#!/bin/bash

HOST=$1
SERVICE=$2
ACTION=$3

# Valida entrada
if [ -z "$SERVICE" ] || [ -z "$ACTION" ]; then
    echo "[ERRO] Uso: scully all -m service <serviço> <ação>"
    echo "Ações suportadas: start | stop | restart | enable | disable | status"
    exit 1
fi

# Executa remotamente via SSH
ssh "$HOST" "sudo systemctl $ACTION $SERVICE && echo '[OK] $ACTION em $SERVICE em $HOST' || echo '[ERRO] Falha ao executar $ACTION em $SERVICE em $HOST'"
