#!/bin/bash

HOST="$1"
shift

COMANDO="$*"

if [[ -z "$COMANDO" ]]; then
    echo "ERRO: Uso: shell.sh <host> <comando>"
    exit 1
fi

ssh "$HOST" "bash -c '$COMANDO'"

if [[ $? -ne 0 ]]; then
    echo "❌ Erro ao executar o comando: $COMANDO"
    exit 1
fi
