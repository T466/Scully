#!/bin/bash
HOST=$1

echo "[INFO] Solicitando reboot do host $HOST..."
ssh "$HOST" "sudo reboot" && echo "[OK] Reboot solicitado para $HOST"
