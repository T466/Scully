#!/bin/bash

PATH_TARGET=$1
STATE=$2
MODE=$3

# Verificações básicas
if [[ -z "$PATH_TARGET" || -z "$STATE" || -z "$MODE" ]]; then
  echo "ERRO: Uso: file.sh <path> <touch|directory> <mode>"
  exit 1
fi

# Executa a ação conforme o tipo
case "$STATE" in
  touch)
    touch "$PATH_TARGET"
    chmod "$MODE" "$PATH_TARGET"
    echo "Arquivo $PATH_TARGET criado com permissão $MODE"
    ;;
  directory)
    mkdir -p "$PATH_TARGET"
    chmod "$MODE" "$PATH_TARGET"
    echo "Diretório $PATH_TARGET criado com permissão $MODE"
    ;;
  *)
    echo "ERRO: Estado inválido. Use 'touch' ou 'directory'."
    exit 1
    ;;
esac
