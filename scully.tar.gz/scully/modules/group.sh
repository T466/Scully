#!/bin/bash

ACAO=$1
GRUPO=$2

if [[ -z "$ACAO" || -z "$GRUPO" ]]; then
  echo "ERRO: Uso: group.sh <add|remove> <nome_do_grupo>"
  exit 1
fi

if [[ "$ACAO" == "add" ]]; then
  if getent group "$GRUPO" &> /dev/null; then
    echo "Grupo $GRUPO já existe"
  else
    groupadd "$GRUPO" && echo "Grupo $GRUPO criado com sucesso"
  fi

elif [[ "$ACAO" == "remove" ]]; then
  if getent group "$GRUPO" &> /dev/null; then
    groupdel "$GRUPO" && echo "Grupo $GRUPO removido com sucesso"
  else
    echo "Grupo $GRUPO não existe"
  fi

else
  echo "Ação inválida. Use 'add' ou 'remove'"
  exit 1
fi
