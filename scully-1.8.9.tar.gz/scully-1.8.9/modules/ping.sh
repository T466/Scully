#!/bin/bash
HOST=$1
ping -c 1 "$HOST" > /dev/null 2>&1 && echo "$HOST OK" || echo "$HOST FALHOU"
