#!/bin/bash
HOST=$1
USERNAME=$2
ssh "$HOST" "sudo useradd -m $USERNAME && echo '[OK] Usuário $USERNAME criado em $HOST'"
